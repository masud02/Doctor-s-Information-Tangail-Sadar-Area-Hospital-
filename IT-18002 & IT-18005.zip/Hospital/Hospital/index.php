<!DOCTYPE html>
<html lang="en">

    
<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>United Hospital</title>
        <meta name="description" content="" />
        <meta name="keywords" content="" />
        <meta name="author" content="ThemesBoss" />

        <link rel="shortcut icon" href="images/favicon.ico">

        <!--Bootstrap Css-->
        <link rel="stylesheet" href="css/bootstrap.min.css" />

        <!-- Materialdesign icons Css -->
        <link rel="stylesheet" href="css/materialdesignicons.min.css">

        <!-- Mobirise icons Css -->
        <link rel="stylesheet" href="css/mobiriseicons.css">

        <!-- Magnific-popup -->
        <link rel="stylesheet" href="css/magnific-popup.css">

        <!-- Animate Css -->
        <link rel="stylesheet" href="css/animate.min.css">

        <!-- Owl Slider -->
        <link rel="stylesheet" href="css/owl.carousel.css" />
        <link rel="stylesheet" href="css/owl.theme.css" />
        <link rel="stylesheet" href="css/owl.transitions.css" />

        <!-- Custom style Css -->
        <link rel="stylesheet" href="css/style.css">

        <script src="https://code.jquery.com/jquery-1.10.2.js" type="text/javascript"></script>
        <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js" type="text/javascript"></script>
        <link type="text/css" rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.min.css" />


        <style>
            .bg-image{
                background-image: url("images/bg-1.png");
            }
        </style>
</head>

    <body>


        <!-- START NAVBAR -->
        <nav class="navbar navbar-expand-lg fixed-top custom-nav sticky">
            <div class="container">
                <!-- LOGO -->
                <a class="navbar-brand logo" href="index.php">
                        <h3 class=" logo-light">United Hospital</h3>
                        <h3 class=" logo-dark">United Hospital</h3>
                    </a>

                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="mdi mdi-menu"></i>
                    </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active">
                            <a href="#home" class="nav-link">Home</a>
                        </li>
                        <li class="nav-item">
                            <a href="index.php#about" class="nav-link">Doctor List</a>
                        </li>
                        
                        <li class="nav-item">
                            <a href="#client" class="nav-link">Patient Review</a>
                        </li>
                        <li class="nav-item">
                            <a href="#contact" class="nav-link">Contact</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- END NAVBAR -->

        <!--START HOME-->
        <section class="home-bg bg-image section h-100vh" id="home">
            <div class="bg-overlay"></div>
            <div class="home-table">
                <div class="home-table-center">
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-12">
                                <div class="text-white text-center">
                                    <h4> Welcome</h4>
                                    <h5>This is United Clinic, as one of the fast growing healthcare service oriented conglomerate, technologically updated, modernized, well equipped and advanced Hospital in Tangail, Bangladesh.</span></h5>
            
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="scroll_down">
                <a href="#about" class="scroll">
                    <i class="mbri-arrow-down text-white"></i>
                </a>
            </div>
        </section>
        <!--END HOME-->

        <!-- START ABOUT -->
        <section class="section" id="about">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-12">
                        <div class="text-center mx-auto section-main-title">
                            <h2><span class="font-weight-bold">Doctor </span>List</h2>
                            <div class="main-title-border">
                                <i class="mdi mdi-asterisk"></i>
                            </div>
                            </div>
                    </div>
                </div>
                <div class="row mt-4 pt-4">
                    <div class="col-lg-12" style="padding-bottom:200px;">
                    <table class="table table-hover table-striped table-bordered" id="myTable">
                            
                            <thead>
                                <tr>
                                    <th>SL. No</th>
                                    <th>Doctor name</th>
                                    <th>Specialist</th>
                                    <th>Details</th>
                                    <th>Appoinment Hour</th>
                                    <th>Off Day</th>
                                    <th>Hospital Name</th>
                                </tr>
                            </thead>
                            <tbody>
                            <?php 

include('includes/config.php');
$query=mysqli_query($con,"Select * from  doctor");
$cnt=1;
while($row=mysqli_fetch_array($query))
{
?>
                                <tr>
                                    <td><?php echo htmlentities($cnt);?></td>
                                    <td><?php echo htmlentities($row['name']);?></td>
                                    <td><?php echo htmlentities($row['specialist']);?></td>
                                    <td><?php echo htmlentities($row['details']);?></td>
                                    <td><?php echo htmlentities($row['appoinment_hour']);?></td>
                                    <td><?php echo htmlentities($row['off_day']);?></td>
                                    <td><?php echo htmlentities($row['hospital_name']);?></td>
                                </tr>
                                <?php $cnt++; } ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </section>
        <!-- END ABOUT -->

       <!-- START Patient Review -->
       <section class="section bg-client" id="client">
            <div class="bg-overlay"></div>
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-12">
                        <div class="text-center mx-auto text-white section-main-title">
                            <h2>Our <span class="font-weight-bold">Patient Review</span></h2>
                            <div class="main-title-border">
                                <i class="mdi mdi-asterisk"></i>
                            </div>
                            <p style='padding-top:60px; padding-bottom:50px' class="mx-auto mt-2">Behavior of some doctors such as Dr. Jahangir Kabir and Dr. Aminul Hasan is very aristocratic, we are very impressed by them, most doctors are good, some junior consultants are also good, the food is excellent and waiters are also excellent, three years ago we did a bypass surgery here - United Hospital was in full swing then full of ambience and life

</p>
                        </div>
                    </div>
                </div>
               
            </div>
        </section>
        <!-- END Patient Review -->


        <!-- CONTACT FORM START-->
        <section class="section " id="contact">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-12">
                        <div class="text-center mx-auto section-main-title">
                            <h2>Get In <span class="font-weight-bold">Tuch</span></h2>
                            <div class="main-title-border">
                                <i class="mdi mdi-asterisk"></i>
                            </div>
                            </div>
                    </div>
                </div>  
                <div class="row mt-4 pt-4">
                    <div class="col-lg-12">
                        <div class="text-center mt-4">
                            <div>
                                <i class="mbri-mobile2 text-custom h2"></i>
                            </div>
                            <div class="mt-2">
                                <p class="mb-0 font-weight-bold">Call Us On</p>
                                <p class="text-muted">+966 1985 123 7856</p>
                            </div>
                        </div>
                        <div class="text-center mt-4">
                            <div>
                                <i class="mbri-letter text-custom h2"></i>
                            </div>
                            <div class="mt-2">
                                <p class="mb-0 font-weight-bold">Email Us At</p>
                                <p class="text-muted">united.hospital@gmail.com</p>
                            </div>
                        </div>
                        <div class="text-center mt-4">
                            <div>
                                <i class="mbri-pin text-custom h2"></i>
                            </div>
                            <div class="mt-2">
                                <p class="mb-0 font-weight-bold">Visit hospital</p>
                                <p class="text-muted">Tangail, Bangladesh</p>
                            </div>
                        </div>
                    </div>
                </div>                          
            </div>
        </section> 
        <!-- CONTACT FORM END-->

        <!-- START FOOTER -->
        <section class="bg-light">
            <div class="container">
                <div class="row pt-4 pb-4">
                    <div class="col-lg-12">
                        <div class="float-left float_none mt-2 mb-2">
                            <p class="copy-rights text-muted mb-0">2021 &copy; United Hospital</p>
                        </div>
                        <div class="float-right float_none mt-2 mb-2">
                            <ul class="list-inline fot_social mb-0">
                                <li class="list-inline-item"><a href="#" class="social-icon text-muted"><i class="mdi mdi-facebook"></i></a></li>
                                <li class="list-inline-item"><a href="#" class="social-icon text-muted"><i class="mdi mdi-twitter"></i></a></li>
                                <li class="list-inline-item"><a href="#" class="social-icon text-muted"><i class="mdi mdi-linkedin"></i></a></li>
                                <li class="list-inline-item"><a href="#" class="social-icon text-muted"><i class="mdi mdi-google-plus"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- END FOOTER -->

        <!-- BACK TO TOP -->    
        <a href="#" class="back_top"> <i class="mbri-arrow-up"> </i> </a>


        <!-- JAVASCRIPTS -->
        <script src="js/jquery.min.js"></script>
        <script src="js/popper.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <!--EASING JS-->
        <script src="js/jquery.easing.min.js"></script>
        <script src="js/scrollspy.min.js"></script>
        <!-- TYPED -->
        <script src="js/typed.js"></script>         
        <!-- MFP JS -->
        <script src="js/jquery.magnific-popup.min.js"></script>
        <!--PORTFOLIO FILTER JS-->
        <script src="js/isotope.js"></script>     
        <!-- OWL CAROUSEL -->
        <script src="js/owl.carousel.min.js"></script>
        <!--CUSTOM JS-->
        <script src="js/custom.js"></script>
        <script>
    $(document).ready(function () {

        $("#myTable").DataTable();

    });
</script>
        <script>
            $(".element").each(function() {
                var $this = $(this);
                $this.typed({
                    strings: $this.attr('data-elements').split(','),
                    typeSpeed: 100,
                    backDelay: 3000
                });
            });
        </script>
    </body>
</html>