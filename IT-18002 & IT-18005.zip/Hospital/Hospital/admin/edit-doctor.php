<?php
session_start();
include('includes/config.php');
error_reporting(0);
if(strlen($_SESSION['login'])==0)
  { 
header('location:index.php');
}
else{
if(isset($_POST['submit']))
{
$catid=intval($_GET['cid']);
$name            = $_POST['name'];
$specialist      = $_POST['specialist'];
$details         = $_POST['details'];
$appoinmentHour  = $_POST['appoinment_hour'];
$offDay          = $_POST['off_day'];
$hospitalName    = $_POST['hospital_Name'];
$query      =mysqli_query($con,"Update  doctor set name='$name',specialist='$specialist',details='$details',appoinment_hour='$appoinmentHour',off_day='$offDay',hospital_name='$hospitalName' where id='$catid'");
if($query)
{
?>
<script type="text/javascript">
            alert("Doctor successfully updated !");
            window.history.back();
        </script>

<?php }
else{ ?>
<script type="text/javascript">
            alert("Something went wrong !");
            window.history.back();
        </script> 
<?php } 
}


?>


<?php include 'includes/header.php' ?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Update Doctor</h1>
                </div>
                <?php 
$catid=intval($_GET['cid']);
$query=mysqli_query($con,"Select * from  doctor where id='$catid'");
$cnt=1;
while($row=mysqli_fetch_array($query))
{
?>

                <form role="form" method="POST">
                                        
                    <div class="form-group">
                        <label>Doctor Name</label>
                        <input class="form-control"  name="name" value="<?php echo htmlentities($row['name']);?>" required>
                    </div>
                    <div class="form-group">
                        <label>Specialist</label>
                        <input class="form-control"  name="specialist" value="<?php echo htmlentities($row['specialist']);?>" required>
                    </div>
                    <div class="form-group">
                        <label>Details</label>
                        <input class="form-control"  name="details" value="<?php echo htmlentities($row['details']);?>" required>
                    </div>
                    <div class="form-group">
                        <label>Appoinment Hour</label>
                        <input class="form-control"  name="appoinment_hour" value="<?php echo htmlentities($row['appoinment_hour']);?>" required>
                    </div>
                    <div class="form-group">
                        <label>Off Day</label>
                        <input class="form-control"  name="off_day" value="<?php echo htmlentities($row['off_day']);?>" required>
                    </div>
                    <div class="form-group">
                        <label>Hospital Name</label>
                        <input class="form-control"  name="hospital_Name" value="<?php echo htmlentities($row['hospital_name']);?>" required>
                    </div>
                    <button type="submit" class="btn btn-success" name="submit">Edit</button>
                    <button type="reset" class="btn btn-danger">Reset</button>
                </form>
                <!-- /.col-lg-12 -->
            </div>
            <!-- /.row -->
            <div class="row">
</div>      
    </div>
    <!-- /#wrapper -->
<?php }} ?>
    <?php include 'includes/footer.php' ?>
