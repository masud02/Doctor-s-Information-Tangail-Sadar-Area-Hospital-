<?php
session_start();
include('includes/config.php');
error_reporting(0);
if(strlen($_SESSION['login'])==0)
  { 
header('location:index.php');
}
else{
if($_GET['action']=='del' && $_GET['rid'])
{
	$id=intval($_GET['rid']);
	$query=mysqli_query($con,"DELETE from doctor where id='$id'");
?>
	   <script type="text/javascript">
            alert("Doctors info deleted !");
            window.history.back();
        </script>

<?php 
}


?>
<?php include 'includes/header.php' ?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Doctor-List</h1>
                </div>
                <!-- /.col-lg-12 -->

                
                <table class="table table-hover table-striped table-bordered" id="myTable">
                            
                                <thead>
                                    <tr>
                                        <th>SL. No</th>
                                        <th>Name</th>
                                        <th>Specialist</th>
                                        <th>Details</th>
                                        <th>Appoinment Hour</th>
                                        <th>Off Day</th>
                                        <th>Hospital Name</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php 
$query=mysqli_query($con,"Select * from  doctor");
$cnt=1;
while($row=mysqli_fetch_array($query))
{
    
?>
                                    <tr>
                                        <td><?php echo htmlentities($cnt);?></td>
                                        <td><?php echo htmlentities($row['name']);?></td>
                                        <td><?php echo htmlentities($row['specialist']);?></td>
                                        <td><?php echo htmlentities($row['details']);?></td>
                                        <td><?php echo htmlentities($row['appoinment_hour']);?></td>
                                        <td><?php echo htmlentities($row['off_day']);?></td>
                                        <td><?php echo htmlentities($row['hospital_name']);?></td>
                                        <td><a href="edit-doctor.php?cid=<?php echo htmlentities($row['id']);?>"><i class="fa fa-pencil" style="color: #29b6f6;"></i></a> 
	&nbsp;<a href="doctor-list.php?rid=<?php echo htmlentities($row['id']);?>&&action=del"> <i class="fa fa-trash-o" style="color: #f05050"></i></a> </td>

                                    </tr>
                                    <?php $cnt++; } ?>
                                </tbody>
                            </table>

            </div>
            <!-- /.row -->
            <div class="row">
</div>      
    </div>
    <!-- /#wrapper -->
<?php } ?>
    <?php include 'includes/footer.php' ?>
