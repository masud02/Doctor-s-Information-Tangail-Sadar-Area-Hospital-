<?php 
session_start();
include('includes/config.php');
error_reporting(0);
if(strlen($_SESSION['login'])==0)
  { 
header('location:index.php');
}
else{

// For adding post  
if(isset($_POST['submit']))
{
$doctorId        = $_POST['id'];
$name            = $_POST['name'];
$specialist      = $_POST['specialist'];
$details         = $_POST['details'];
$appoinmentHour  = $_POST['appoinmentHour'];
$offDay          = $_POST['offDay'];
$hospitalName    = $_POST['hospitalName'];


$query=mysqli_query($con,"insert into doctor(name,specialist,details,appoinment_hour,off_day,hospital_name) values('$name','$specialist','$details','$appoinmentHour','$offDay','$hospitalName')");
if($query)
{
    ?>
        <script type="text/javascript">
            alert("Doctor successfully added !");
            window.history.back();
        </script>
<?php
}
else {
    ?>
        <script type="text/javascript">
            alert("Something went wrong !");
            window.history.back();
        </script>
    <?php

    } 


}
?>
<?php include 'includes/header.php' ?>
        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Add Doctor</h1>
                </div>
                <!-- /.col-lg-12 -->
                <form role="form" method="POST">                   
                    <div class="form-group">
                        <label>Name</label>
                        <input class="form-control" placeholder="Enter doctor name" name="name" required>
                    </div>
                    <div class="form-group">
                        <label>Specialist</label>
                        <input class="form-control" placeholder="Enter Specialist" name="specialist" required>
                    </div>
                    <div class="form-group">
                        <label>Details</label>
                        <input class="form-control" placeholder="Enter details about the doctor" name="details" required>
                    </div>
                    <div class="form-group">
                        <label>Appoinment Hour</label>
                        <input class="form-control" placeholder="Enter surface type" name="appoinmentHour" required>
                    </div>
                    <div class="form-group">
                        <label>Off-day</label>
                        <input class="form-control" placeholder="Enter surafce condition" name="offDay" required>
                    </div>
                    <div class="form-group">
                        <label>Hospital Name</label>
                        <input class="form-control" placeholder="Enter hospital name" name="hospitalName" required>
                    </div>

                    
                    <button type="submit" class="btn btn-success" name="submit">Submit Button</button>
                    <button type="reset" class="btn btn-danger">Reset Button</button>
                </form>
            </div>
            <!-- /.row -->
            <div class="row">
</div>      
    </div>
    <!-- /#wrapper -->
<?php } ?>
    <?php include 'includes/footer.php' ?>
