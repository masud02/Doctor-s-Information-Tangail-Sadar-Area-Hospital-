-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 09, 2021 at 04:47 AM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hospital`
--

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `specialist` varchar(255) NOT NULL,
  `details` varchar(255) NOT NULL,
  `appoinment_hour` varchar(255) NOT NULL,
  `off_day` varchar(255) NOT NULL,
  `hospital_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`id`, `name`, `specialist`, `details`, `appoinment_hour`, `off_day`, `hospital_name`) VALUES
(3, 'Dr Mamun', 'Gynoclogist', 'MBBS,FCPS', '3PM - 9PM', 'Friday, Saturday, Sunday', 'Medinova Hospital'),
(5, 'Dr Masud', 'Sexologist', 'MBBS,FCPS', '2PM - 8 PM', 'Saturday, Sunday', 'Sonya Clinic'),
(6, 'Dr Meraz', 'Therapist', 'BSC in Physiotherapy from BHPI', '6PM - 10PM', 'Saturday, Sunday', 'Sonya Clinic'),
(7, 'Md. Bashar', 'Sexologist', 'MBBS,FCPS', '6PM - 10PM', 'Saturday, Sunday', ''),
(8, 'Md. Hafizur Rahman', 'Therapist', 'MBBS,FCPS', '6PM - 10PM', 'Saturday, Sunday', ''),
(9, 'Habibur', 'Therapist', 'MBBS,FCPS', '6PM - 10PM', 'Saturday, Sunday', ''),
(10, 'Habibur', 'Gynoclogist', 'MBBS,FCPS', '6PM - 10PM', 'Saturday, Sunday', ''),
(11, 'Rabeya Khatun', 'Gynoclogist', 'MBBS,FCPS', '6PM - 10PM', 'Saturday, Sunday', ''),
(12, 'Dr Ritu Biswas', 'Gynoclogist', 'MBBS,FCPS', '6PM - 10PM', 'Friday, Tuesday', ''),
(13, 'Dr Samima Yeasmin', 'Gynoclogist', 'MBBS,FCPS', '6PM - 10PM', 'Wednesday, Tuesday', ''),
(14, 'Dr Sabrina Afroz', 'Gynoclogist', 'MBBS,FCPS', '6PM - 10PM', 'Wednesday, Tuesday', ''),
(15, 'Dr Umar Ali', 'Psychologist', 'MBBS,FCPS', '6PM - 10PM', 'Wednesday, Tuesday', ''),
(16, 'Dr Tushar Bhuiya', 'Psychologist', 'MBBS,FCPS', '6PM - 10PM', 'Friday, Tuesday', ''),
(17, 'Md. Hafizur Rahman', 'Psychologist', 'MBBS,FCPS', '6PM - 10PM', 'Friday, Tuesday', 'Medinova Hospital');

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

CREATE TABLE `tbladmin` (
  `id` int(11) NOT NULL,
  `AdminUserName` varchar(255) NOT NULL,
  `AdminPassword` varchar(255) NOT NULL,
  `AdminEmailId` varchar(255) NOT NULL,
  `Is_Active` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`id`, `AdminUserName`, `AdminPassword`, `AdminEmailId`, `Is_Active`) VALUES
(1, 'admin', '123456', 'samim@gmail.com', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
